<!DOCTYPE html>
<html>
    <?php
        include('db_connect');
    ?>
	<head>
        <title>Y.E.O.M, Your Excellent On-time Meals</title>
        <link rel="stylesheet" type="text/css" href="styles/main.css">
        <!--script for logging in-->
        <script
        src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
        </script>
        <script>src="jquery.validate.js"</script>
        <script>
        //validate the login input
        function validate_log(){
            //check the email
            if ($("#email").val()==""){
                alert("Enter e-mail");
               return false;
            //checking the password is valid 
            }else if ($("#password").val()==""){
                alert("Please enter password");
                return false;
            }
        }
        </script>
	</head>
    <body>
    <!--page nave bar-->
    <div id="pagetop">
    <ul id="pagetop">
        <li id="top"><p id="yeom">Y.E.O.M</p></li>
        <li id="top"><a href="mainpage.php">Home</a></li>
        <li id="top"><a href="registration.html">Register</a></li>
        <li id="top"><a href="lazenbys.html">lazenby's</a></li>
        <li id="top"><a href="theref.html">The Ref</a></li>
        <li id="top"><a href="tradetable.html">Trade Table</a></li>
        <li id="top"><a href="mastermenu.html">Master Menu</a></li>
    </ul>
    </div>
    <br><br>
    <!--form for logging in-->
    <div id="loginform">
        <p> Before ordering you must Login or Register</p>
        <form id="loginfields" method="post" action="" onsubmit="validate_log();">
            <fieldset>
                <legend>Login</legend>
                <!--getting login email-->
                <p>
                    <label for="email">E-mail</label>
                    <input id="email" type="email" name="email" />
                </p>
                <!--login password-->
                <p>
                    <label for="password">Password</label>
                    <input id="password" type="password" name="password" />
                </p>
                <p>
                    <input type="submit" value="login" id="submit">
                </p>
            </fieldset>
        </form>
        <br>
        <!--sending user to register-->
         <a href="registration.html" id="reg">Register Here</a>
    </div>
        
    <br><br><br>
    <!--buttons for menus-->
    <div id="menubutt"> 
        <a id="llink" href="lazenbys.html">Lazenby's Menu</a>
        <a id="relink" href="theref.html">Refectory Menu</a>  
        <a id="trlink" href="tradetable.html">Trade Table Menu</a>    
    </div>
    </body>
</html>