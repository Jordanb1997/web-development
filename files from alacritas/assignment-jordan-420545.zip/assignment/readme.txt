//important stuff is in here

director of the board login:
id: DN1000
fullname: Director of the Board
id_number: 111111
email: director@utas.edu.au
phone number: 0412345678
password: Abc123!
card name: Director of the Board
card number: 1234567891
card expiry date: 11/01
security number/ccv: 111

test student:
US1111
student
123456
student@utas.edu.au
0412345679
Abc123!
student
1234567890
11/02
123


